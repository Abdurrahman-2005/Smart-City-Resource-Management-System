import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

// ─────────────────────────────────────────────────────────────────────────────────
//  DOMAIN CLASSES & REPOSITORY
// ─────────────────────────────────────────────────────────────────────────────────

interface Alertable {
    void sendEmergencyAlert();
    //end method sendEmergencyAlert
}
//end interface Alertable

interface Reportabe {
    String generateUsageReport();
    //end method generateUsageReport
}
//end interface Reportabe

abstract class CityResource implements Reportabe {
    protected int resourceID;
    protected String location;
    protected String status;

    public CityResource() {
        this.resourceID = 0;
        this.location   = "";
        this.status     = "";
    }
    //end constructor CityResource

    public CityResource(int resourceID, String location, String status) {
        this.resourceID = resourceID;
        this.location   = location;
        this.status     = status;
    }
    //end constructor CityResource

    public int getResourceID() { return resourceID; }
    //end method getResourceID

    public void setResourceID(int resourceID) { this.resourceID = resourceID; }
    //end method setResourceID

    public String getLocation()  { return location; }
    //end method getLocation

    public void setLocation(String location) { this.location = location; }
    //end method setLocation

    public String getStatus()    { return status; }
    //end method getStatus

    public void setStatus(String status) { this.status = status; }
    //end method setStatus

    abstract double calculateMaintenanceCost();
    //end method calculateMaintenanceCost

    String ToString() { return ""; }
    //end method ToString

    public String generateUsageReport(){ return ""; }
    //end method generateUsageReport
}
//end class CityResource

/**
 * CityRepository
 *   - on construction, attempts to connect to MongoDB
 *   - provides a static `fetch` method for login checks
 */
class CityRepository<T> {
    public CityRepository() {
        System.out.println("[CityRepository] Starting MongoDB connection thread...");
        new Thread(() -> {
            try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
                MongoDatabase db = mongoClient.getDatabase("smart_city");
                System.out.println("[CityRepository] Connected to database: " + db.getName());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
    //end constructor CityRepository

    /**
     * Attempt to fetch a user document from the "users" collection matching email/password.
     * Returns true if found (login success), false otherwise.
     */
    public static boolean fetch(String email, String password) {
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase db = mongoClient.getDatabase("smart_city");
            MongoCollection<Document> users = db.getCollection("users");
            Document query = new Document("email", email).append("password", password);
            FindIterable<Document> result = users.find(query);
            return result.first() != null;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    //end method fetch

    String ToString() { return ""; }
    //end method ToString

    String generateUsageReport(){ return ""; }
    //end method generateUsageReport
}
//end class CityRepository

/**
 * SmartGrid
 *   - Tracks total energy consumed (kWh) and total distance covered (km).
 *   - Maintains lists of active PowerStations and TransportationUnits for management.
 */
class SmartGrid implements Reportabe {
    protected PowerStation[] powerStations;
    protected Consumer[] consumers;
    private static volatile double energyConsumed = 0.0;
    private static volatile double distanceCovered = 0.0;

    // Keep a global registry of emergency services so PowerStation can dispatch alerts.
    static List<Alertable> emergencyRegistry = new ArrayList<>();

    public SmartGrid() {
        this.powerStations = new PowerStation[0];
        this.consumers     = new Consumer[0];
        energyConsumed     = 0.0;
        distanceCovered    = 0.0;
    }
    //end constructor SmartGrid

    public SmartGrid(PowerStation[] powerStations, Consumer[] consumers) {
        this.powerStations = powerStations;
        this.consumers     = consumers;
    }
    //end constructor SmartGrid

    public PowerStation[] getPowerStations() { return powerStations; }
    //end method getPowerStations

    public void setPowerStations(PowerStation[] powerStations) { this.powerStations = powerStations; }
    //end method setPowerStations

    public Consumer[] getConsumers() { return consumers; }
    //end method getConsumers

    public void setConsumers(Consumer[] consumers) { this.consumers = consumers; }
    //end method setConsumers

    public static double getEnergyConsumed() { return energyConsumed; }
    //end method getEnergyConsumed

    public static void addEnergy(double amount) { energyConsumed += amount; }
    //end method addEnergy

    public static double getDistanceCovered() { return distanceCovered; }
    //end method getDistanceCovered

    public static void addDistance(double km) { distanceCovered += km; }
    //end method addDistance

    @Override
    public String ToString() { return ""; }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return "Total Energy: " + energyConsumed + " kWh | Total Distance: " + distanceCovered + " km";
    }
    //end method generateUsageReport
}
//end class SmartGrid

/**
 * TransportUnit
 *   - Upon creation, can start a background thread that simulates fuel consumption (distance → km).
 */
class TransportUnit extends CityResource implements Reportabe {
    private volatile boolean running = false;
    private Thread fuelThread;
    private double journeyDistance; // total km to simulate
    private volatile double coveredSoFar = 0.0;

    public TransportUnit() {
        super();
        this.journeyDistance = 0.0;
    }
    //end constructor TransportUnit

    public TransportUnit(int resourceID, String location, String status, double journeyDistance) {
        super(resourceID, location, status);
        this.journeyDistance = journeyDistance;
    }
    //end constructor TransportUnit

    /**
     * Start a background thread that, every second, increments coveredSoFar by 1 km
     * until it reaches journeyDistance; each increment also updates SmartGrid.distanceCovered.
     */
    public void startFuelThread() {
        if (running) return;
        running = true;
        fuelThread = new Thread(() -> {
            while (running && coveredSoFar < journeyDistance) {
                try {
                    Thread.sleep(1000);
                    coveredSoFar += 1.0; // 1 km per second for demo
                    SmartGrid.addDistance(1.0);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        fuelThread.setDaemon(true);
        fuelThread.start();
    }
    //end method startFuelThread

    public void stopFuelThread() {
        running = false;
        if (fuelThread != null) fuelThread.interrupt();
    }
    //end method stopFuelThread

    @Override
    double calculateMaintenanceCost(){
        // e.g., cost = $0.10 per km
        return coveredSoFar * 0.10;
    }
    //end method calculateMaintenanceCost

    @Override
    public String ToString() {
        return "TransportUnit[id=" + resourceID + ", loc=" + location + ", status=" + status +
               ", covered=" + coveredSoFar + "/" + journeyDistance + "]";
    }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return "Driven: " + coveredSoFar + " km | Maintenance Cost: $" + calculateMaintenanceCost();
    }
    //end method generateUsageReport
}
//end class TransportUnit

/**
 * Bus & Train simply extend TransportUnit (could be customized further later)
 */
class Bus extends TransportUnit implements Reportabe {
    public Bus() { super(); }
    //end constructor Bus

    public Bus(int resourceID, String location, String status, double journeyDistance) {
        super(resourceID, location, status, journeyDistance);
    }
    //end constructor Bus

    @Override
    public String ToString() {
        return "[Bus] " + super.ToString();
    }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return super.generateUsageReport();
    }
    //end method generateUsageReport
}
//end class Bus

class Train extends TransportUnit implements Reportabe {
    public Train() { super(); }
    //end constructor Train

    public Train(int resourceID, String location, String status, double journeyDistance) {
        super(resourceID, location, status, journeyDistance);
    }
    //end constructor Train

    @Override
    public String ToString() {
        return "[Train] " + super.ToString();
    }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return super.generateUsageReport();
    }
    //end method generateUsageReport
}
//end class Train

/**
 * PowerStation
 *   - On creation, can start a background thread to simulate energy production (kWh).
 *   - Can trigger outages/alerts to registered emergency services.
 */
class PowerStation extends CityResource implements Reportabe, Alertable {
    private volatile boolean running = false;
    private Thread energyThread;
    private double productionRate; // kWh per second

    public PowerStation() {
        super();
        this.productionRate = 1.0; // default 1 kWh/sec
    }
    //end constructor PowerStation

    public PowerStation(int resourceID, String location, String status, double productionRate) {
        super(resourceID, location, status);
        this.productionRate = productionRate;
    }
    //end constructor PowerStation

    /**
     * Start a background thread that, every second, increments SmartGrid.energyConsumed
     * by productionRate kWh.
     */
    public void startEnergyThread() {
        if (running) return;
        running = true;
        energyThread = new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(1000);
                    SmartGrid.addEnergy(productionRate);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        energyThread.setDaemon(true);
        energyThread.start();
    }
    //end method startEnergyThread

    /** 
     * Halt production for a fixed outage period, alert emergency services, then resume.
     */
    public void outage() {
        sendEmergencyAlert(); 
        // stop producing for 2 seconds, but keep current energy count
        running = false;
        new Thread(() -> {
            try {
                Thread.sleep(2000); // 2 seconds outage
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            startEnergyThread(); // resume production
        }).start();
    }
    //end method outage

    @Override
    public void sendEmergencyAlert() {
        // Notify all registered emergency services
        for (Alertable svc : SmartGrid.emergencyRegistry) {
            svc.sendEmergencyAlert();
        }
    }
    //end method sendEmergencyAlert

    @Override
    double calculateMaintenanceCost(){
        // e.g., $0.05 per kWh
        return SmartGrid.getEnergyConsumed() * 0.05;
    }
    //end method calculateMaintenanceCost

    @Override
    public String ToString() {
        return "PowerStation[id=" + resourceID + ", loc=" + location + ", status=" + status + "]";
    }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return "Energy Produced: " + SmartGrid.getEnergyConsumed() + " kWh | Maintenance Cost: $"
               + calculateMaintenanceCost();
    }
    //end method generateUsageReport
}
//end class PowerStation

/**
 * EmergencyService
 *   - Base for Police & Firefighter; simply logs alerts
 */
class EmergencyService extends CityResource implements Alertable, Reportabe {
    private static double emergencyResponseTime = 0;

    public EmergencyService() { super(); }
    //end constructor EmergencyService

    public EmergencyService(int resourceID, String location, String status) {
        super(resourceID, location, status);
    }
    //end constructor EmergencyService

    public static double getEmergencyResponseTime() { return emergencyResponseTime; }
    //end method getEmergencyResponseTime

    public static void setEmergencyResponseTime(double time) { emergencyResponseTime = time; }
    //end method setEmergencyResponseTime

    @Override
    double calculateMaintenanceCost(){ return 0.0; }
    //end method calculateMaintenanceCost

    @Override
    public void sendEmergencyAlert() {
        System.out.println("[EmergencyService] Alert received! Dispatching units from " + location);
    }
    //end method sendEmergencyAlert

    @Override
    public String ToString() {
        return "[EmergencyService] id=" + resourceID + ", loc=" + location + ", status=" + status;
    }
    //end method ToString

    @Override
    public String generateUsageReport() {
        return "[EmergencyService] No usage metrics";
    }
    //end method generateUsageReport
}
//end class EmergencyService

class Police extends EmergencyService implements Reportabe {
    public Police() { super(); }
    //end constructor Police

    public Police(int resourceID, String location, String status) {
        super(resourceID, location, status);
    }
    //end constructor Police

    @Override
    public void sendEmergencyAlert() {
        System.out.println("[Police] Responding to alert at " + getLocation());
    }
    //end method sendEmergencyAlert

    @Override
    public String generateUsageReport() {
        return "[Police] Report: No consumable usage.";
    }
    //end method generateUsageReport
}
//end class Police

class Firefighter extends EmergencyService implements Reportabe {
    public Firefighter() { super(); }
    //end constructor Firefighter

    public Firefighter(int resourceID, String location, String status) {
        super(resourceID, location, status);
    }
    //end constructor Firefighter

    @Override
    public void sendEmergencyAlert() {
        System.out.println("[Firefighter] Heading to " + getLocation());
    }
    //end method sendEmergencyAlert

    @Override
    public String generateUsageReport() {
        return "[Firefighter] Report: No consumable usage.";
    }
    //end method generateUsageReport
}
//end class Firefighter

/**
 * CityZone, ResourceHub, TransportationHub, Consumer, Household, Industry
 *   - Minimal stubs to compile and satisfy skeleton
 */
class CityZone implements Reportabe {
    protected ResourceHub[] resources;

    public CityZone() {
        this.resources = new ResourceHub[0];
    }
    //end constructor CityZone

    public CityZone(ResourceHub[] resources) { this.resources = resources; }
    //end constructor CityZone

    public ResourceHub[] getResources() { return resources; }
    //end method getResources

    public void setResources(ResourceHub[] resources) { this.resources = resources; }
    //end method setResources

    @Override
    public String ToString() { return ""; }
    //end method ToString

    @Override
    public String generateUsageReport(){ return ""; }
    //end method generateUsageReport
}
//end class CityZone

class ResourceHub implements Reportabe {
    public ResourceHub() {}
    //end constructor ResourceHub

    @Override
    public String generateUsageReport(){ return ""; }
    //end method generateUsageReport
}
//end class ResourceHub

class TransportationHub extends ResourceHub implements Reportabe {
    protected Bus[] busses;
    protected Train[] trains;

    public TransportationHub() {
        this.busses = new Bus[0];
        this.trains = new Train[0];
    }
    //end constructor TransportationHub

    public TransportationHub(Bus[] busses, Train[] trains) {
        this.busses = busses;
        this.trains = trains;
    }
    //end constructor TransportationHub

    public Bus[] getBusses() { return busses; }
    //end method getBusses

    public void setBusses(Bus[] busses) { this.busses = busses; }
    //end method setBusses

    public Train[] getTrains() { return trains; }
    //end method getTrains

    public void setTrains(Train[] trains) { this.trains = trains; }
    //end method setTrains

    @Override
    public String ToString() { return ""; }
    //end method ToString

    @Override
    public String generateUsageReport(){ return ""; }
    //end method generateUsageReport
}
//end class TransportationHub

class Consumer {
    protected int id;
    protected String name;

    public Consumer() {
        this.id = 0;
        this.name = "";
    }
    //end constructor Consumer

    public Consumer(int id, String name) {
        this.id = id;
        this.name = name;
    }
    //end constructor Consumer

    public int getId() { return id; }
    //end method getId

    public void setId(int id) { this.id = id; }
    //end method setId

    public String getName() { return name; }
    //end method getName

    public void setName(String name) { this.name = name; }
    //end method setName

    String ToString() { return ""; }
    //end method ToString
}
//end class Consumer

class Household extends Consumer {
    public Household() { super(); }
    //end constructor Household

    public Household(int id, String name) { super(id, name); }
    //end constructor Household

    @Override
    public String ToString() { return ""; }
    //end method ToString
}
//end class Household

class Industry extends Consumer {
    public Industry() { super(); }
    //end constructor Industry

    public Industry(int id, String name) { super(id, name); }
    //end constructor Industry

    @Override
    public String ToString() { return ""; }
    //end method ToString
}
//end class Industry

/**
 * LabFinal
 *   - Instantiates CityRepository (to start Mongo connection thread),
 *     then launches JavaFX application (App).
 */
public class LabFinal {
    public LabFinal() {}
    //end constructor LabFinal

    public static void main(String[] args) {
        new CityRepository<>();             // Fire up MongoDB connection test
        Application.launch(App.class, args);
        System.out.println("[LabFinal] JavaFX exited.");
    }
    //end method main
}
//end class LabFinal
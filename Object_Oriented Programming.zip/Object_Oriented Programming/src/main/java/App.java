import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.application.Application;

public class App extends Application {
    private Stage primaryStage;
    private Scene loginScene, mainScene;
    private boolean isAdmin = false;     // track role after login

    // References to domain objects (in a real app, you'd store these in lists)
    private PowerStation currentStation;
    private TransportUnit currentTrip;
    private Police policeService, policeBackup;
    private Firefighter fireService, fireBackup;

    @Override
    public void start(Stage stage)  {
        this.primaryStage = stage;
        stage.setTitle("Smart City Resource Management");

        // 1) Build Login Scene
        loginScene = buildLoginScene();

        // 2) Build Main Scene (but we’ll show it only after successful login)
        mainScene = buildMainScene();

        stage.setScene(loginScene);
        stage.setResizable(false);
        stage.show();
    }
    //end method start

    /** Build a simple login form (email/password + role radio buttons) */
    private Scene buildLoginScene() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label lblEmail = new Label("Email:");
        TextField tfEmail = new TextField();
        tfEmail.setPromptText("email@example.com");

        Label lblPassword = new Label("Password:");
        PasswordField pfPassword = new PasswordField();
        pfPassword.setPromptText("password");

        // Role selection
        ToggleGroup roleGroup = new ToggleGroup();
        RadioButton rbAdmin = new RadioButton("Admin");
        rbAdmin.setToggleGroup(roleGroup);
        RadioButton rbUser = new RadioButton("User");
        rbUser.setToggleGroup(roleGroup);
        rbUser.setSelected(true);

        HBox roleBox = new HBox(10, rbAdmin, rbUser);
        roleBox.setAlignment(Pos.CENTER);

        Button btnLogin = new Button("Login");
        Label loginMsg = new Label();
        loginMsg.setStyle("-fx-text-fill: red;");

        btnLogin.setOnAction(ev -> {
            String email = tfEmail.getText().trim();
            String pwd   = pfPassword.getText().trim();
            boolean ok = CityRepository.fetch(email, pwd);
            if (!ok) {
                loginMsg.setText("Invalid credentials!");
                return;
            }
            // Determine role
            isAdmin = rbAdmin.isSelected();
            loginMsg.setText("");
            primaryStage.setTitle("Logged in as " + (isAdmin ? "Admin" : "User"));
            primaryStage.setScene(mainScene);
        });

        root.getChildren().addAll(
            lblEmail, tfEmail,
            lblPassword, pfPassword,
            new Label("Select Role:"), roleBox,
            btnLogin, loginMsg
        );

        return new Scene(root, 350, 300);
    }
    //end method buildLoginScene

    /** 
     * Build the main dashboard:
     *   - If Admin: show “Create PowerStation” form
     *   - If User: show “Consume Energy”, “Start Trip”, “Call Emergency” sections
     */
    private Scene buildMainScene() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));

        // Section: Create / Manage PowerStation (Admin only)
        Label lblStation = new Label("PowerStation Management (Admin only)");
        TextField tfStationID       = new TextField();
        tfStationID.setPromptText("Station ID (integer)");
        TextField tfStationLoc      = new TextField();
        tfStationLoc.setPromptText("Location");
        TextField tfStationRate     = new TextField();
        tfStationRate.setPromptText("Production Rate (kWh/sec)");
        Button btnCreateStation     = new Button("Create & Start Station");
        Label stationMsg            = new Label();
        stationMsg.setStyle("-fx-text-fill: green;");

        btnCreateStation.setOnAction(e -> {
            if (!isAdmin) {
                stationMsg.setText("Access denied: Admin only.");
                return;
            }
            try {
                int id = Integer.parseInt(tfStationID.getText());
                String loc = tfStationLoc.getText().trim();
                double rate = Double.parseDouble(tfStationRate.getText());
                currentStation = new PowerStation(id, loc, "Running", rate);
                currentStation.startEnergyThread();
                stationMsg.setText("PowerStation created at '" + loc + "'");
                // Register emergency services for this demo
                SmartGrid.emergencyRegistry.clear();
                policeService = new Police(1, "Central Police HQ", "Ready");
                fireService   = new Firefighter(2, "Central Fire Station", "Ready");
                SmartGrid.emergencyRegistry.add(policeService);
                SmartGrid.emergencyRegistry.add(fireService);
            } catch (NumberFormatException ex) {
                stationMsg.setText("Invalid input: ID must be int, rate must be double.");
            }
        });

        VBox adminBox = new VBox(5,
            lblStation,
            tfStationID, tfStationLoc, tfStationRate,
            btnCreateStation, stationMsg
        );
        adminBox.setPadding(new Insets(10));
        adminBox.setStyle("-fx-border-color: gray; -fx-border-width: 1;");

        // Section: Consume Energy (User only)
        Label lblConsume = new Label("Declare Appliances & Consume Energy (User only)");
        CheckBox cbFan = new CheckBox("Fan (0.8 kWh/sec)");
        CheckBox cbAC  = new CheckBox("AC (2.0 kWh/sec)");
        Button btnStartConsume = new Button("Start Energy Consumption");
        Label consumeMsg = new Label();
        consumeMsg.setStyle("-fx-text-fill: green;");

        btnStartConsume.setOnAction(e -> {
            if (isAdmin) {
                consumeMsg.setText("Access denied: Users only.");
                return;
            }
            if (currentStation == null) {
                consumeMsg.setText("No PowerStation exists yet!");
                return;
            }
            // Determine total appliance consumption rate
            double totalRate = 0.0;
            if (cbFan.isSelected()) totalRate += 0.8;
            if (cbAC.isSelected())  totalRate += 2.0;
            if (totalRate <= 0.0) {
                consumeMsg.setText("Select at least one appliance.");
                return;
            }
            // Create a dummy Consumer to “attach” to station:
            Consumer userConsumer = new Consumer(100, "EndUser");
            // Launch a background thread to add energy usage into SmartGrid:
            Thread consThread = new Thread(() -> {
                int elapsed = 0;
                while (elapsed < 5000) { // run for 5 seconds
                    try {
                        Thread.sleep(1000);
                        SmartGrid.addEnergy(totalRate);
                        elapsed += 1000;
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                }
            });
            consThread.setDaemon(true);
            consThread.start();
            consumeMsg.setText("Consumption started at " + totalRate + " kWh/sec for 5 sec.");
        });

        VBox userConsumeBox = new VBox(5,
            lblConsume, cbFan, cbAC,
            btnStartConsume, consumeMsg
        );
        userConsumeBox.setPadding(new Insets(10));
        userConsumeBox.setStyle("-fx-border-color: gray; -fx-border-width: 1;");

        // Section: Start a Trip (User only)
        Label lblTrip = new Label("Start Transport Trip (User only)");
        TextField tfTripID      = new TextField();
        tfTripID.setPromptText("Trip ID (integer)");
        TextField tfTripLoc     = new TextField();
        tfTripLoc.setPromptText("Origin Location");
        TextField tfTripDist    = new TextField();
        tfTripDist.setPromptText("Journey Distance (km)");
        Button btnStartTrip     = new Button("Start Trip");
        Label tripMsg           = new Label();
        tripMsg.setStyle("-fx-text-fill: green;");

        btnStartTrip.setOnAction(e -> {
            if (isAdmin) {
                tripMsg.setText("Access denied: Users only.");
                return;
            }
            if (tfTripID.getText().isEmpty() || tfTripLoc.getText().isEmpty() || tfTripDist.getText().isEmpty()) {
                tripMsg.setText("Fill all trip details.");
                return;
            }
            try {
                int id = Integer.parseInt(tfTripID.getText());
                String loc = tfTripLoc.getText().trim();
                double dist = Double.parseDouble(tfTripDist.getText());
                currentTrip = new TransportUnit(id, loc, "EnRoute", dist);
                currentTrip.startFuelThread();
                tripMsg.setText("Trip started: " + dist + " km from " + loc);
            } catch (NumberFormatException ex) {
                tripMsg.setText("Invalid ID or distance.");
            }
        });

        VBox userTripBox = new VBox(5,
            lblTrip, tfTripID, tfTripLoc, tfTripDist,
            btnStartTrip, tripMsg
        );
        userTripBox.setPadding(new Insets(10));
        userTripBox.setStyle("-fx-border-color: gray; -fx-border-width: 1;");

        // Section: Emergency / Outage
        Label lblEmergency = new Label("Emergency / Outage");
        Button btnOutage = new Button("Trigger PowerStation Outage");
        Label outageMsg   = new Label();
        outageMsg.setStyle("-fx-text-fill: maroon;");
        Button btnReport  = new Button("Generate City Report");
        Label reportLabel = new Label();
        reportLabel.setWrapText(true);

        btnOutage.setOnAction(e -> {
            if (currentStation == null) {
                outageMsg.setText("No PowerStation to outage!");
                return;
            }
            currentStation.outage();
            outageMsg.setText("Outage triggered. Emergency services notified.");
        });

        btnReport.setOnAction(e -> {
            StringBuilder sb = new StringBuilder();
            if (currentStation != null) {
                sb.append(currentStation.generateUsageReport()).append("\n");
            }
            if (currentTrip != null) {
                sb.append(currentTrip.generateUsageReport()).append("\n");
            }
            sb.append("City Aggregate: ").append(new SmartGrid().generateUsageReport());
            reportLabel.setText(sb.toString());
        });

        VBox emergencyBox = new VBox(5,
            lblEmergency, btnOutage,
            btnReport, reportLabel, outageMsg
        );
        emergencyBox.setPadding(new Insets(10));
        emergencyBox.setStyle("-fx-border-color: gray; -fx-border-width: 1;");

        // Assemble all sections into one scrollable pane
        VBox allSections = new VBox(20,
            adminBox,
            new Separator(),
            userConsumeBox,
            new Separator(),
            userTripBox,
            new Separator(),
            emergencyBox
        );
        allSections.setPadding(new Insets(10));

        ScrollPane scroll = new ScrollPane(allSections);
        scroll.setFitToWidth(true);
        scroll.setPrefViewportHeight(600);

        return new Scene(scroll, 450, 650);
    }
    //end method buildMainScene

    public static void main(String[] args) {
        launch(args);
    }
    //end method main
}
//end class App